# run dragon.py
from marshal import loads
exec(loads(open('dragon.py','rb').read()))